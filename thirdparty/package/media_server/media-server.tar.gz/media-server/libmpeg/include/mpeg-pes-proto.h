#ifndef _mpeg_pes_proto_h_
#define _mpeg_pes_proto_h_

#pragma message("This file is deprecated. Please use \"mpeg-ts.h\" or \"mpeg-ps.h\" only")

#endif /* !_mpeg_pes_proto_h_ */

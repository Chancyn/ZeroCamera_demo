#include <stdio.h>

void http_benchmark();

int main(int argc, char* argv[])
{
	http_benchmark();
	return 0;
}

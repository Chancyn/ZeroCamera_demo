
extern const char tmp_example[];

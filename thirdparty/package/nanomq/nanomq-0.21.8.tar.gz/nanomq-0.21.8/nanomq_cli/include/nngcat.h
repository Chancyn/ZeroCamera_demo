#ifndef NANOMQ_NNGCAT_H
#define NANOMQ_NNGCAT_H

int nng_cat_dflt(int ac, char **av);

#endif // NANOMQ_NNGCAT_H
